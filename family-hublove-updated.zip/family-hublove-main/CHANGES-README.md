# OurNest — What changed and how to deploy it

## What was fixed

1. **The "stuck loading" spinner.** The old backend stored everyone's data in
   one shared file in this repo and committed to GitHub on every change —
   including a 15-second "online" heartbeat from each phone. Every read had
   to download and decode that whole growing file, and concurrent writes
   (two phones pinging every 15s) frequently conflicted. That's now replaced
   with Redis (see below) — reads and writes are both near-instant, and each
   type of data (events, settings, presence...) is stored separately so they
   can't collide with each other.

2. **The lost anniversary date.** Same root cause — the settings save was
   silently failing under write conflicts, with no retry and no error shown.
   Confirmed from your uploaded backup: neither of your two hub codes had an
   anniversary date saved, matching exactly what you described. The save
   path now retries automatically, reports a real error if it ever truly
   fails, and won't touch local state until the server confirms the write.

3. **Games felt repetitive / limited.** The smaller decks (compliments,
   letter prompts, dice prompts, wheel activities, story starters, trivia)
   only had 7–12 items each, so they cycled back quickly. These are now
   expanded to 22–37 items each. Added two new sweet games:
   - 🌙 **Pillow Talk** — soft wind-down questions for before sleep
   - 🍯 **Sweet Nothings** — a short affectionate line to say out loud, on demand

## Deploy steps

1. **Create a Redis database** (2 minutes, free tier is plenty):
   - Easiest: in your Vercel project → **Storage** tab → **Create Database**
     → choose **Upstash Redis** (sometimes labeled "KV"). Vercel will set the
     environment variables for you automatically.
   - Or manually: sign up at https://upstash.com → create a Redis database →
     copy the REST URL and REST Token into your Vercel project's
     **Settings → Environment Variables**:
     - `UPSTASH_REDIS_REST_URL`
     - `UPSTASH_REDIS_REST_TOKEN`

2. **Migrate your existing data** (events, diary, wishlist, etc. — this does
   NOT bring back the anniversary date, since it was never actually saved,
   but everything else carries over):
   ```bash
   npm install
   export UPSTASH_REDIS_REST_URL="paste-your-url"
   export UPSTASH_REDIS_REST_TOKEN="paste-your-token"
   node scripts/migrate-to-redis.js
   ```

3. **Deploy as usual** (push to your connected GitHub repo, or `vercel deploy`).

4. **Re-enter your special date** in the app once — 20th August 2025 — it
   will now actually persist.

5. You can safely remove the old `GH_STORE_TOKEN` environment variable from
   Vercel once you've confirmed the new version is working — it's no longer
   used.

## Notes
- `data/store.json` is kept as a backup/reference of your old data — the
  live app no longer reads from it after deployment.
- If you ever want to bump the presence heartbeat interval (currently 15s,
  in `index.html`'s `startPresence()`), Redis handles it fine — the old
  concern about hammering GitHub commits doesn't apply anymore.
